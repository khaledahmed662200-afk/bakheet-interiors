import { NextResponse } from 'next/server'

const RESEND_ENDPOINT = 'https://api.resend.com/emails'
const RECIPIENT = process.env.INQUIRY_RECIPIENT_EMAIL || 'bakheetos53@gmail.com'
const SENDER = process.env.INQUIRY_SENDER_EMAIL || 'website@bakheett.com'

function clean(value: unknown, maxLength = 2000) {
  if (typeof value !== 'string') return ''
  return value.replace(/[<>]/g, '').trim().slice(0, maxLength)
}

function formatValue(value: unknown) {
  if (Array.isArray(value)) return value.map((item) => clean(item, 200)).join('، ')
  return clean(value)
}

export async function POST(request: Request) {
  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) {
    return NextResponse.json(
      { error: 'Email service is not configured. Missing RESEND_API_KEY.' },
      { status: 503 },
    )
  }

  let payload: Record<string, unknown>
  try {
    payload = await request.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  const name = clean(payload.name, 120)
  const phone = clean(payload.phone, 60)
  if (!name || !phone) {
    return NextResponse.json({ error: 'Name and phone are required.' }, { status: 400 })
  }

  const fields = Object.entries(payload)
    .filter(([key]) => !['name', 'phone'].includes(key))
    .map(([key, value]) => `${key}: ${formatValue(value)}`)
    .join('\n')

  const emailResponse = await fetch(RESEND_ENDPOINT, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: `BAKHEET Website <${SENDER}>`,
      to: [RECIPIENT],
      subject: `New website inquiry from ${name}`,
      text: `New BAKHEET website inquiry\n\nName: ${name}\nPhone: ${phone}\n${fields}`,
    }),
  })

  if (!emailResponse.ok) {
    const resendError = await emailResponse.text()
    console.error('[v0] Resend inquiry failed:', emailResponse.status, resendError)
    return NextResponse.json({ error: 'Unable to send inquiry.' }, { status: 502 })
  }

  return NextResponse.json({ success: true })
}

export async function GET() {
  return NextResponse.json({ error: 'Method not allowed.' }, { status: 405 })
}
