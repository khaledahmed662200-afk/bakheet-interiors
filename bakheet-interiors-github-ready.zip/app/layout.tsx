import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'BAKHEET | Construction & Finishing Company in Cairo & Sheikh Zayed',
  description:
    'BAKHEET provides architectural and structural design, engineering supervision, quantity surveying, full project execution, and professional finishing services in Cairo and Sheikh Zayed, Egypt.',
  openGraph: {
    siteName: 'BAKHEET',
    title: 'BAKHEET | Construction & Finishing Company in Cairo & Sheikh Zayed',
    description:
      'BAKHEET provides architectural and structural design, engineering supervision, quantity surveying, full project execution, and professional finishing services in Cairo and Sheikh Zayed, Egypt.',
    url: 'https://bakheett.com/',
    type: 'website',
    images: [{ url: 'https://bakheett.com/bakheet-favicon.png', alt: 'BAKHEET logo' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BAKHEET | Construction & Finishing Company in Cairo & Sheikh Zayed',
    description:
      'BAKHEET provides architectural and structural design, engineering supervision, quantity surveying, full project execution, and professional finishing services in Cairo and Sheikh Zayed, Egypt.',
    images: ['https://bakheett.com/bakheet-favicon.png'],
  },
  alternates: {
    canonical: 'https://bakheett.com/',
  },
  icons: {
    icon: '/bakheet-favicon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: 'white' },
    { media: '(prefers-color-scheme: dark)', color: 'black' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
