const structuredData = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'WebSite',
      name: 'BAKHEET',
      alternateName: ['Bakheet', 'بخيت', 'بخيت للتشطيبات', 'BAKHEET Construction', 'BAKHEET Interiors'],
      url: 'https://bakheett.com/',
    },
    {
      '@type': ['Organization', 'LocalBusiness'],
      name: 'BAKHEET',
      alternateName: ['Bakheet', 'بخيت', 'بخيت للتشطيبات', 'BAKHEET Construction', 'BAKHEET Interiors'],
      url: 'https://bakheett.com/',
      areaServed: [
        { '@type': 'City', name: 'Cairo', containedInPlace: { '@type': 'Country', name: 'Egypt' } },
        { '@type': 'City', name: 'Sheikh Zayed', containedInPlace: { '@type': 'Country', name: 'Egypt' } },
      ],
      knowsAbout: [
        'Construction',
        'Finishing',
        'Architectural design',
        'Structural design',
        'Engineering supervision',
        'Quantity surveying',
        'Full project execution',
        'Interior finishing',
      ],
    },
  ],
}


export default function Page() {
  return (
    <main className="min-h-screen">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />
      <iframe
        src="/bakheet.html"
        title="بخيت للتشطيبات والديكور"
        className="block h-screen w-full border-0"
      />
    </main>
  )
}

