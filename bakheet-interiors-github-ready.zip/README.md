# BAKHEET Interiors

Official website for BAKHEET Interiors — Interior Design, Finishing & Engineering Solutions.

## Project
A modern bilingual (Arabic/English) website focused on interior design, finishing, engineering services, projects, offers, and lead generation.

## Tech
- Next.js / React
- TypeScript
- Tailwind/CSS
- Responsive design

## Owner
Khaled Ahmed

LinkedIn: https://www.linkedin.com/in/khaled-ahmed-2b152b35a/
